
package t3a1;

public class Calificaciones {
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String grupo;
    private String carrera;
    private String nombreAsignatura1;
    private String nombreAsignatura2;
    private int calificacion1; 
    private int calificacion2;
    
    private double promedio;

    public int getCalificacion1() {
        return calificacion1;
    }

    public void setCalificacion1(int calificacion1) {
        this.calificacion1 = calificacion1;
    }

    public int getCalificacion2(int calificacion2) {
        return calificacion2; 
    }

    public void setCalificacion2(int calificacion2) {
        this.calificacion2 = calificacion2;
    }
    
    public Calificaciones() {  }

    public Calificaciones(String nombre, String apellidoPaterno, String apellidoMaterno, String grupo, String carrera, String nombreAsignatura1, String nombreAsignatura2, int calificacion1, int calificacion2, double promedio) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.grupo = grupo;
        this.carrera = carrera;
        this.calificacion1 = calificacion1;
        this.calificacion2 = calificacion2;
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return "Calificaciones{" + "nombre=" + nombre + 
        ", apellidoPaterno=" + apellidoPaterno + ", apellidoMaterno=" +
        apellidoMaterno + ", grupo=" + grupo + ", carrera=" + carrera + 
        ", nombreAsignatura1=" + nombreAsignatura1 + ", calificacion1=" + 
        calificacion1 + ", promedio=" + promedio + '}';
    }
    
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

  

    public int getCalificacion() {
        return calificacion1;
    }

    public void setCalificacion(int calificacion) {
        this.calificacion1 = calificacion;
    }

    
    
    public double getPromedio() {
        
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    public String getNombreAsignatura1() {
        return nombreAsignatura1;
    }

    public void setNombreAsignatura1(String nombreAsignatura1) {
        this.nombreAsignatura1 = nombreAsignatura1;
    }

    public String getNombreAsignatura2() {
        return nombreAsignatura2;
    }

    public void setNombreAsignatura2(String nombreAsignatura2) {
        this.nombreAsignatura2 = nombreAsignatura2;
    }
    
    
    
}
    